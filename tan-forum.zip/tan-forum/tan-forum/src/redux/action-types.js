/*
包含n个action type 名称常量
 */
export const AUTH_SUCCESS = 'auth_sucess'; //注册/登录成功
export const ERROR_MSG = 'error_msg';//注册/登录错误
export const RECEIVE_USER = 'receive_user';  // 接受用户
export const RESET_USER = 'reset_user'  //重置用户

export const POSTS_SUCCESS = 'posts_sucess'; //获取帖子成功

export const ADDPOSTS_SUCCESS = 'addposts_sucess'; //增加帖子成功

export const DLEPOSTS_SUCCESS = 'dleposts_sucess'; //删除帖子成功

export const COMMENT_SUCCESS = 'comment_sucess'; //获取评论帖子成功

export const ADDCOMMENT_SUCCESS = 'addcomment_sucess'; //增加帖子成功

export const EMAIL_SUCCESS = 'comment_sucess'; //邮箱验证码发送成功

export const VALIDATE_SUCCESS = 'comment_sucess'; //验证码验证成功